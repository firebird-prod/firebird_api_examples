package com.firebird;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.json.Json;
import javax.json.JsonReader;
import javax.json.JsonException;
import javax.json.JsonObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

class SwapQueryParameters {
	public static String from;
	public static String to;
	public static int amount;
    public static int saveGas;
	public static int gasInclude;
	public static String compareDexes;
	
	SwapQueryParameters(String _from, String _to, int _amount, int _saveGas, int _gasInclude, String _compareDexes) {
		from = _from;
		to = _to;
		amount = _amount;
		saveGas = _saveGas;
		gasInclude = _gasInclude;
		compareDexes = _compareDexes;
	}
	
	public Set<Map.Entry<String, String>> entrySet()  {
		Map<String, String>  _queryParameterMap = new HashMap<>();
		_queryParameterMap.put("from", from);
		_queryParameterMap.put("to", to);
		_queryParameterMap.put("amount", String.valueOf(amount));
		_queryParameterMap.put("saveGas", String.valueOf(saveGas));
		_queryParameterMap.put("gasInclude", String.valueOf(gasInclude));
		_queryParameterMap.put("compareDexes", compareDexes);

		return _queryParameterMap.entrySet();
	}
}

public class swapIntegration {
    public static void main(String[] args) throws IOException {
    	String firebirdApiUrl = "https://router.firebird.finance";
    	String resource = "/fantom/route";
    	
        // Create a swap transaction 100 USDC to WFTM
		SwapQueryParameters swapTransaction = new SwapQueryParameters(
			"0x04068da6c83afcfa0e13ba15a6696662335d5b75", //USDC
			"0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83", //WFTM
			100000000, //100.000000
			0,
			0,
			"spookyswap" //effects singleDexReturn response
		);
		
		// Construct request URI and fill in query parameters
		StringBuilder queries = new StringBuilder();
		for(Map.Entry<String, String> query: swapTransaction.entrySet()) {
	        queries.append( "&" + query.getKey()+"="+query.getValue());
	    }

        URL url = new URL(firebirdApiUrl + resource + '?' + queries.substring(1));

        // Send GET request to Firebird's API
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		connection.setRequestProperty("User-Agent", "Firebird Java api example");
		connection.setRequestProperty("Accept", "application/json");
		
		int responseCode = connection.getResponseCode();
		long responseHeaderDate = connection.getHeaderFieldDate("date", 0);
		if (responseCode == HttpURLConnection.HTTP_OK) {
			BufferedReader in = new BufferedReader( new InputStreamReader( connection.getInputStream() ) );
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// Convert response from string to JSON
			try {
				String str = response.toString();
				JsonReader jsonReader = Json.createReader(new StringReader(str));
				JsonObject parsedJSON = jsonReader.readObject();
				DateFormat dateFormat = new SimpleDateFormat("E, d MMM YYYY hh:mm:ss z");
				TimeZone time_zone = TimeZone.getTimeZone("GMT");
				dateFormat.setTimeZone(time_zone);
				System.out.println("Quoted @ " + dateFormat.format(responseHeaderDate));
				System.out.println(parsedJSON);
			} catch (JsonException err) {
				System.out.println("Exception : "+err.toString());
			}
		} else {
			System.out.println("GET request failed");
		}
    }
}
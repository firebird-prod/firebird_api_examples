import requests
	
class swapIntegration:
	def swap( fromTokenAddress, toTokenAddress, amount, saveGas, gasInclude, compareDexes ):
		#Construct request URI and fill in query parameters
		firebirdApiUrl = 'https://router.firebird.finance'
		resource = '/fantom/route'
		url = firebirdApiUrl + resource
		
		params = dict({'from':fromTokenAddress,
			'to':toTokenAddress,
			'amount':amount,
			'saveGas':saveGas,
			'gasInclude':gasInclude,
			'compareDexes':compareDexes
		})
		
		headers = { 'User-Agent': "Firebird Python api example", "Accept": "application/json" }
		
		#Send GET request to Firebird's API
		res = requests.get(url=url, params=params, headers=headers)
		
		#Convert response from string to JSON
		parsed = res.json()
		headers = res.headers
		
		maxReturn = parsed['maxReturn']
		print("Quoted @ " + headers['Date'])
		print(maxReturn)

#Create a swap transaction 100 USDC to WFTM
swapIntegration.swap(
	"0x04068da6c83afcfa0e13ba15a6696662335d5b75", #USDC
	"0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83", #WFTM
	str(100000000), #100.000000
	str(0),
	str(0),
	"spookyswap" #effects singleDexReturn response
)
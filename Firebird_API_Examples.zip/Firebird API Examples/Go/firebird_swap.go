package main

import (
	"fmt"
	"log"
	"io"
	"net/http"
	"net/url"
	"strconv"
)

type SwapQueryParameters struct {
    from	string
    to	string
    amount	int
    saveGas	int
	gasInclude	int
	compareDexes	string
}

func main() {
	firebirdApiUrl := "https://router.firebird.finance"
	resource := "/fantom/route"
	
	// Create a swap transaction 100 USDC to WFTM
	swapTransaction := SwapQueryParameters{
		from: "0x04068da6c83afcfa0e13ba15a6696662335d5b75", //USDC
		to: "0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83", //WFTM
		amount: 100000000, //100.000000
		saveGas: 0,
		gasInclude: 0,
		compareDexes: "spookyswap", //effects singleDexReturn response
	}
	
	// Construct request URI and fill in query parameters
	u, _ := url.ParseRequestURI(firebirdApiUrl)
	u.Path = resource
	
	data := u.Query()
	data.Add( "from", swapTransaction.from )
	data.Add( "to", swapTransaction.to )
	data.Add( "amount", strconv.Itoa(swapTransaction.amount) )
	data.Add( "saveGas", strconv.Itoa(swapTransaction.saveGas) )
	data.Add( "gasInclude", strconv.Itoa(swapTransaction.gasInclude) )
	data.Add( "compareDexes", swapTransaction.compareDexes )
	
	u.RawQuery = data.Encode()
	urlStr := u.String()
	
	r, _ := http.NewRequest(http.MethodGet, urlStr, nil)
    r.Header.Add("User-Agent", "Firebird Golang api example")
	r.Header.Set("Accept", "application/json")
	
	client := &http.Client{}
	
	// Send GET request to Firebird's API
	resp, err := client.Do(r)
	if err != nil {
		log.Fatalln(err)
	}

	defer resp.Body.Close()

	swapResponse, swapErr := io.ReadAll(resp.Body)
	// Go.1.15 and earlier
	//swapResponse, swapErr := ioutil.ReadAll(resp.Body)
	
	if swapErr != nil {
		log.Fatalln(swapErr)
	}

	fmt.Println("Quoted @ " + resp.Header.Get("Date"))
	fmt.Println(string(swapResponse))
}
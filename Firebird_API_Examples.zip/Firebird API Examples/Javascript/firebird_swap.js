var request = require("request-promise")
var firebirdApiUrl = "https://router.firebird.finance"
var resource = "/fantom/route"

//Create a swap transaction 100 USDC to WFTM
var swapQueryParameters = {
		from: "0x04068da6c83afcfa0e13ba15a6696662335d5b75", //USDC
		to: "0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83", //WFTM
		amount: 100000000, //100.000000
		saveGas: 0,
		gasInclude: 0,
		compareDexes: "spookyswap", //effects singleDexReturn response
}

// Construct request URI and fill in query parameters
var firebirdReq = {
	url: `${firebirdApiUrl}${resource}`,
	headers: {
		"User-Agent": "Firebird Javascript api example",
		"Accept": "application/json"
	},
	qs: swapQueryParameters,
	resolveWithFullResponse: true,
	json: true,
}

// Send GET request to Firebird's API
var httpRequest = request.get(firebirdReq);
return httpRequest
	.then((response, err) => {
		if(err) throw err;
		console.log(`Quoted @ ${response.headers.date}`)
		console.log(response.body)
		return response.body;
	})